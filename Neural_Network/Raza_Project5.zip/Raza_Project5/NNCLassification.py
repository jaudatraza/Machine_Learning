import pandas as pd 
import numpy as np 
from random import shuffle 
from random import seed 
from random import random 
from collections import Counter 
from math import exp

# Required Data Set Format
# Columns (0 through N)
# 0: Attribute 0
# 1: Attribute 1 
# 2: Attribute 2
# 3: Attribute 3 
# ...
# N: Actual Class
 
# 2 additional columns are added for the test set.
# N + 1: Predicted Class
# N + 2: Prediction Correct?
 
ALGORITHM_NAME = "Classification Feedforward Neural Network With Backpropagation"
 
def normalize(dataset):
    """
    Normalize the attribute values so that they are between 0 and 1, inclusive
    :param pandas_dataframe dataset: The original dataset as a Pandas dataframe
    :return: normalized_dataset
    :rtype: Pandas dataframe
    """
    # Generate a list of the column names 
    column_names = list(dataset) 
 
    # For every column except the actual class column
    for col in range(0, len(column_names) - 1):  
        temp = dataset[column_names[col]] # Go column by column
        minimum = temp.min() # Get the minimum of the column
        maximum = temp.max() # Get the maximum of the column
 
        # Normalized all values in the column so that they
        # are between 0 and 1.
        # x_norm = (x_i - min(x))/(max(x) - min(x))
        dataset[column_names[col]] = dataset[column_names[col]] - minimum
        dataset[column_names[col]] = dataset[column_names[col]] / (
            maximum - minimum)
 
    normalized_dataset = dataset
 
    return normalized_dataset
 
def get_five_stratified_folds(dataset):
    """
    Implementation of five-fold stratified cross-validation. Divide the data
    set into five random folds. Make sure that the proportion of each class 
    in each fold is roughly equal to its proportion in the entire data set.
    """
    # Create five empty folds
    five_folds = list()
    fold0 = list()
    fold1 = list()
    fold2 = list()
    fold3 = list()
    fold4 = list()
 
    # Get the number of columns in the data set
    class_column = len(dataset[0]) - 1
 
    # Shuffle the data randomly
    shuffle(dataset)
 
    # Generate a list of the unique class values and their counts
    classes = list()  # Create an empty list named 'classes'
 
    # For each instance in the dataset, append the value of the class
    # to the end of the classes list
    for instance in dataset:
        classes.append(instance[class_column])
 
    # Create a list of the unique classes
    unique_classes = list(Counter(classes).keys())
 
    # For each unique class in the unique class list
    for uniqueclass in unique_classes:
 
        # Initialize the counter to 0
        counter = 0
         
        # Go through each instance of the data set and find instances that
        # are part of this unique class. Distribute them among one
        # of five folds
        for instance in dataset:
 
            # If we have a match
            if uniqueclass == instance[class_column]:
 
                # Allocate instance to fold0
                if counter == 0:
 
                    # Append this instance to the fold
                    fold0.append(instance)
 
                    # Increase the counter by 1
                    counter += 1
 
                # Allocate instance to fold1
                elif counter == 1:
 
                    # Append this instance to the fold
                    fold1.append(instance)
 
                    # Increase the counter by 1
                    counter += 1
 
                # Allocate instance to fold2
                elif counter == 2:
 
                    # Append this instance to the fold
                    fold2.append(instance)
 
                    # Increase the counter by 1
                    counter += 1
 
                # Allocate instance to fold3
                elif counter == 3:
 
                    # Append this instance to the fold
                    fold3.append(instance)
 
                    # Increase the counter by 1
                    counter += 1
 
                # Allocate instance to fold4
                else:
 
                    # Append this instance to the fold
                    fold4.append(instance)
 
                    # Reset the counter to 0
                    counter = 0
 
    # Shuffle the folds
    shuffle(fold0)
    shuffle(fold1)
    shuffle(fold2)
    shuffle(fold3)
    shuffle(fold4)
 
    # Add the five stratified folds to the list
    five_folds.append(fold0)
    five_folds.append(fold1)
    five_folds.append(fold2)
    five_folds.append(fold3)
    five_folds.append(fold4)
 
    return five_folds
 
def initialize_neural_net(
    no_inputs, no_hidden_layers, no_nodes_per_hidden_layer, no_outputs):
    """
    Generates a new neural network that is ready to be trained.
    Network (list of layers): 0+ hidden layers, and output layer
    Input Layer (list of attribute values): A row from the training set 
    Hidden Layer (list of dictionaries): A set of nodes (i.e. neurons)
    Output Layer (list of dictionaries): A set of nodes, one node per class
    Node (dictionary): Contains a set of weights, one weight for each input 
      to the layer containing that node + an additional weight for the bias.
      Each node is represented as a dictionary that stores key-value pairs
      Each key corresponds to a property of that node (e.g. weights).
      Weights will be initialized to small random values between 0 and 1.
    """
 
    # Create an empty list
    network = list()
 
    # Create the the hidden layers
    hidden_layer = list()
    hl_counter = 0
 
    # Create the output layer
    output_layer = list()
 
    # If this neural network contains hidden layers
    if no_hidden_layers > 0:
 
        # Build one hidden layer at a time
        for layer in range(no_hidden_layers):
 
            # Reset to an empty hidden layer
            hidden_layer = list()
 
            # If this is the first hidden layer
            if hl_counter == 0:
 
                # Build one node at a time
                for node in range(no_nodes_per_hidden_layer):
 
                    initial_weights = list()
                     
                    # Each node in the hidden layer has no_inputs + 1 weights, 
                    # initialized to a random number in the range [0.0, 1.0)
                    for i in range(no_inputs + 1):
                        initial_weights.append(random())
 
                    # Add the node to the first hidden layer
                    hidden_layer.append({'weights':initial_weights})
 
                # Finished building the first hidden layer
                hl_counter += 1
 
                # Add this first hidden layer to the front of the neural 
                # network
                network.append(hidden_layer)
 
            # If this is not the first hidden layer
            else:
 
                # Build one node at a time
                for node in range(no_nodes_per_hidden_layer):
 
                    initial_weights = list()
                     
                    # Each node in the hidden layer has 
                    # no_nodes_per_hidden_layer + 1 weights, initialized to 
                    # a random number in the range [0.0, 1.0)
                    for i in range(no_nodes_per_hidden_layer + 1):
                        initial_weights.append(random())
 
                    hidden_layer.append({'weights':initial_weights})
 
                # Add this newly built hidden layer to the neural network
                network.append(hidden_layer)
 
        # Build the output layer
        for outputnode in range(no_outputs):
 
            initial_weights = list()
                     
            # Each node in the output layer has no_nodes_per_hidden_layer 
            # + 1 weights, initialized to a random number in 
            # the range [0.0, 1.0)
            for i in range(no_nodes_per_hidden_layer + 1):
                initial_weights.append(random())
 
            # Add this output node to the output layer
            output_layer.append({'weights':initial_weights})
 
        # Add the output layer to the neural network
        network.append(output_layer)
     
    # A neural network has no hidden layers
    else:
 
        # Build the output layer
        for outputnode in range(no_outputs):
         
            initial_weights = list()
                     
            # Each node in the hidden layer has no_inputs + 1 weights, 
            # initialized to a random number in the range [0.0, 1.0)
            for i in range(no_inputs + 1):
                initial_weights.append(random())
 
            # Add this output node to the output layer
            output_layer.append({'weights':initial_weights})
 
        network.append(output_layer)
 
    # Finished building the initial neural network
    return network
 
def weighted_sum_of_inputs(weights, inputs):
    """
    Calculates the weighted sum of inputs plus the bias
    """
    # We assume that the last weight is the bias value
    # The bias value is a special weight that does not multiply with an input
    # value (or we could assume its corresponding input value is always 1)
    # The bias is similar to the intercept constant b in y = mx + b. It enables
    # a (e.g. sigmoid) curve to be shifted to create a better fit
    # to the data. Without the bias term b, the line always goes through the 
    # origin (0,0) and cannot adapt as well to the data.
    # In y = mx + b, we assume b * x_0 where x_0 = 1
 
    # Initiate the weighted sum with the bias term. Assume the last weight is
    # the bias term
    weighted_sum = weights[-1]
 
    for index in range(len(weights) - 1):
        weighted_sum += weights[index] * inputs[index]
 
    return weighted_sum
 
def sigmoid(weighted_sum_of_inputs_plus_bias):
    """
    Run the weighted sum of the inputs + bias through
    the sigmoid activation function.
    """
    return 1.0 / (1.0 + exp(-weighted_sum_of_inputs_plus_bias))
 
def forward_propagate(network, instance):
    """
    Instances move forward through the neural network from one layer
    to the next layer. At each layer, the outputs are calculated for each 
    node. These outputs are the inputs for the nodes in the next layer.
    The last set of outputs is the output for the nodes in the output 
    layer.
    """
    inputs = instance
 
    # For each layer in the neural network
    for layer in network:
 
        # These will store the outputs for this layer
        new_inputs = list()
 
        # For each node in this layer
        for node in layer:
 
            # Calculate the weighted sum + bias term
            weighted_sum = weighted_sum_of_inputs(node['weights'], inputs)
 
            # Run the weighted sum through the activation function
            # and store the result in this node's dictionary.
            # Now the node's dictionary has two keys, weights and output.
            node['output'] = sigmoid(weighted_sum)
 
            # Used for debugging
            #print(node)
 
            # Add the output of the node to the new_inputs list
            new_inputs.append(node['output'])
 
        # Update the inputs list
        inputs = new_inputs
 
    # We have reached the output layer
    outputs = inputs
 
    return outputs
 
def sigmoid_derivative(output):
    """
    The derivative of the sigmoid activation function with respect 
    to the weighted summation term of the node.
    Formally (after a lot of calculus), this derivative is:
        derivative = sigmoid(weighted_sum_of_inputs_plus_bias) * 
        (1 - sigmoid(weighted_sum_of_inputs_plus_bias))
                   = node_ouput * (1 - node_output)
    This method is used during the backpropagation phase. 
    """
    return output * (1.0 - output)
 
def back_propagate(network, actual):
    """
    In backpropagation, the error is computed between the predicted output by 
    the network and the actual output as determined by the data set. This error 
    propagates backwards from the output layer to the first hidden layer. The 
    weights in each layer are updated along the way in response to the error. 
    The goal is to reduce the prediction error for the next training instance 
    that forward propagates through the network.
    """
    # Iterate in reverse order (i.e. starts from the output layer)
    for i in reversed(range(len(network))):
 
        # Work one layer at a time
        layer = network[i]
 
        # Keep track of the errors for the nodes in this layer
        errors = list()
 
        # If this is a hidden layer
        if i != len(network) - 1:
 
            # For each node_j in this hidden layer
            for j in range(len(layer)):
 
                # Reset the error value
                error = 0.0
 
                # Calculate the weighted error. 
                # The error values come from the error (i.e. delta) calculated
                # at each node in the layer just to the "right" of this layer. 
                # This error is weighted by the weight connections between the 
                # node in this hidden layer and the nodes in the layer just 
                # to the "right" of this layer.
                for node in network[i + 1]:
                    error += (node['weights'][j] * node['delta'])
 
                # Add the weighted error for node_j to the
                # errors list
                errors.append(error)
         
        # If this is the output layer
        else:
 
            # For each node in the output layer
            for j in range(len(layer)):
                 
                # Store this node (i.e. dictionary)
                node = layer[j]
 
                # Actual - Predicted = Error
                errors.append(actual[j] - node['output'])
 
        # Calculate the delta for each node_j in this layer
        for j in range(len(layer)):
            node = layer[j]
 
            # Add an item to the node's dictionary with the 
            # key as delta.
            node['delta'] = errors[j] * sigmoid_derivative(node['output'])
 
def update_weights(network, instance, learning_rate):
    """
    After the deltas (errors) have been calculated for each node in 
    each layer of the neural network, the weights can be updated.
    new_weight = old_weight + learning_rate * delta * input_value
    """
    # For each layer in the network
    for layer_index in range(len(network)):
 
        # Extract all the attribute values, excluding the class value
        inputs = instance[:-1]
 
        # If this is not the first hidden layer
        if layer_index != 0:
 
            # Go through each node in the previous layer and add extract the
            # output from that node. The output from the previous layer
            # is the input to this layer.
            inputs = [node['output'] for node in network[layer_index - 1]]
        # For each node in this layer
        for node in network[layer_index]:
            # Go through each input value
            for j in range(len(inputs)):
                # Update the weights
                node['weights'][j] += learning_rate * node['delta'] * inputs[j]
            # Updating the bias weight 
            node['weights'][-1] += learning_rate * node['delta']
 
def train_neural_net(
    network, training_set, learning_rate, no_epochs, no_outputs):
    """
    Train a neural network that has already been initialized.
    Training is done using stochastic gradient descent where the weights
    are updated one training instance at a time rather than after the
    entire training set (as is the case with gradient descent)."""
    # Go through the entire training set a fixed number of times (i.e. epochs)
    for epoch in range(no_epochs):
    
        # Update the weights one instance at a time
        for instance in training_set:
 
            # Forward propagate the training instance through the network
            # and produce the output, which is a list.
            outputs = forward_propagate(network, instance)
 
            # Vectorize the output using one hot encoding. 
            # Create a list called actual_output that is the same length 
            # as the number of outputs. Put a 1 in the place of the actual 
            # class.
            actual_output = [0 for i in range(no_outputs)]
            actual_output[int(instance[-1])] = 1
             
            back_propagate(network, actual_output)
            update_weights(network, instance, learning_rate)
 
def predict_class(network, instance):
    """
    Make a class prediction given a trained neural network and
    an instance from the test data set.
    :param list network: The neural network, which is a list of layers
    :param list instance: A single training/test instance from the data set
    :return class_prediction
    :rtype int
    """
    outputs = forward_propagate(network, instance)
 
    # Return the index that has the highest probability. This index
    # is the class value. Assume class values begin at 0 and go
    # upwards by 1 (i.e. 0, 1, 2, ...)
    class_prediction = outputs.index(max(outputs))
     
    return class_prediction
 
def calculate_accuracy(actual, predicted):
    """
    Calculates the accuracy percentages
    """
    number_of_correct_predictions = 0
    for index in range(len(actual)):
        if actual[index] == predicted[index]:
            number_of_correct_predictions += 1
     
    classification_accuracy = (
        number_of_correct_predictions / float(len(actual))) * 100.0
    return classification_accuracy
 
def get_test_set_predictions(
    training_set, test_set, learning_rate, no_epochs, 
    no_hidden_layers, no_nodes_per_hidden_layer):
    """
    This method is the workhorse. 
    A new neutal network is initialized.
    The network is trained on the training set.
    The trained neural network is used to generate predictions on the
    test data set.
    """
    # Get the number of attribute values
    no_inputs = len(training_set[0]) - 1
 
    # Calculate the number of unique classes
    no_outputs = len(set([instance[-1] for instance in training_set]))
     
    # Build a new neural network
    network = initialize_neural_net(
        no_inputs, no_hidden_layers, no_nodes_per_hidden_layer, no_outputs)
 
    train_neural_net(
        network, training_set, learning_rate, no_epochs, no_outputs)
     
    # Store the class predictions for each test instance
    class_predictions = list()
    for instance in test_set:
        cl_prediction = predict_class(network, instance)
        class_predictions.append(cl_prediction)
 
    # Return the learned model as well as the class predictions
    return network, class_predictions
 
###############################################################
def ANN_Classification(DataFrame, LayerNum, NodePerLayer, DataName):
    """
    The main method of the program
    """
    LEARNING_RATE = 0.1 # Used for stochastic gradient descent procedure
    NO_EPOCHS = 1000 # Epoch is one complete pass through training data
    NO_HIDDEN_LAYERS = LayerNum # Number of hidden layers
    NO_NODES_PER_HIDDEN_LAYER = NodePerLayer # Number of nodes per hidden layer

    # Welcome message
    print("Welcome to the " +  ALGORITHM_NAME + " Program!")
    print()
 
    # Directory where data set is located
    #data_path = input("Enter the path to your input file: ") 
    data_path = DataName
 
    # Read the full text file and store records in a Pandas dataframe
    pd_data_set = DataFrame
 
    # Show functioning of the program 
    trace_runs_file = "ClassificationProblem/"+DataName+"_trace_runs.txt"
 
    ## Open a new file to save trace runs
    outfile_tr = open(trace_runs_file,"w") 
 
    # Testing statistics
    test_stats_file = "ClassificationProblem/"+DataName+"_test_stats.txt"
 
    ## Open a test_stats_file 
    outfile_ts = open(test_stats_file,"w")
 
    # Generate a list of the column names 
    column_names = list(pd_data_set) 
 
    # The input layer in the neural network 
    # will have one node for each attribute value
    no_of_inputs = len(column_names) - 1
 
    # Make a list of the unique classes
    list_of_unique_classes = pd.unique(pd_data_set["Class"])
 
    # The output layer in the neural network 
    # will have one node for each class value
    no_of_outputs = len(list_of_unique_classes)
 
    # Replace all the class values with numbers, starting from 0
    # in the Pandas dataframe.
    for cl in range(0, len(list_of_unique_classes)):
        pd_data_set["Class"].replace(
            list_of_unique_classes[cl], cl ,inplace=True)
 
    # Normalize the attribute values so that they are all between 0 
    # and 1, inclusive
    normalized_pd_data_set = normalize(pd_data_set)
 
    # Convert normalized Pandas dataframe into a list
    dataset_as_list = normalized_pd_data_set.values.tolist()
 
    # Set the seed for random number generator
    seed(1)
 
    # Get a list of 5 stratified folds because we are doing
    # five-fold stratified cross-validation
    fv_folds = get_five_stratified_folds(dataset_as_list)
     
    # Keep track of the scores for each of the five experiments
    scores = list()
     
    experiment_counter = 0
    for fold in fv_folds:
         
        outfile_tr.write("Running Experiment " + str(
            experiment_counter) + " ...\n")
        outfile_tr.write("\n")
 
        # Get all the folds and store them in the training set
        training_set = list(fv_folds)
 
        # Four folds make up the training set
        training_set.remove(fold)        
 
        # Combined all the folds so that all we have is a list
        # of training instances
        training_set = sum(training_set, [])
         
        # Initialize a test set
        test_set = list()
         
        # For each instance in this test fold
        for instance in fold:
             
            # Create a copy and store it
            copy_of_instance = list(instance)
            test_set.append(copy_of_instance)
         
        # Get the trained neural network and the predicted values
        # for each test instance
        neural_net, predicted_values = get_test_set_predictions(
            training_set, test_set,LEARNING_RATE,NO_EPOCHS,
            NO_HIDDEN_LAYERS,NO_NODES_PER_HIDDEN_LAYER)
        actual_values = [instance[-1] for instance in fold]
        accuracy = calculate_accuracy(actual_values, predicted_values)
        scores.append(accuracy)
 
        # Print the learned model
        outfile_tr.write("Experiment " + str(
            experiment_counter) + " Trained Neural Network")
        outfile_tr.write("\n")
        outfile_tr.write("\n")
        for layer in neural_net:
            outfile_tr.write(str(layer))
            outfile_tr.write("\n")
        outfile_tr.write("\n\n")
 
        # Print the classifications on the test instances
        outfile_tr.write("Experiment " + str(
            experiment_counter) + " Classifications on Test Instances")
        outfile_tr.write("\n\n")
        test_df = pd.DataFrame(test_set, columns=column_names)
 
        # Add 2 additional columns to the testing dataframe
        test_df = test_df.reindex(
        columns=[*test_df.columns.tolist(
        ), 'Predicted Class', 'Prediction Correct?'])
 
        # Add the predicted values to the "Predicted Class" column
        # Indicate if the prediction was correct or not.
        for pre_val_index in range(len(predicted_values)):
            test_df.loc[pre_val_index, "Predicted Class"] = predicted_values[
                pre_val_index]
            if test_df.loc[pre_val_index, "Class"] == test_df.loc[
                pre_val_index, "Predicted Class"]:
                test_df.loc[pre_val_index, "Prediction Correct?"] = "Yes"
            else:
                test_df.loc[pre_val_index, "Prediction Correct?"] = "No"
 
        # Replace all the class values with the name of the class
        for cl in range(0, len(list_of_unique_classes)):
            test_df["Class"].replace(
                cl, list_of_unique_classes[cl] ,inplace=True)
            test_df["Predicted Class"].replace(
                cl, list_of_unique_classes[cl] ,inplace=True)
 
        # Print out the test data frame
        #print(test_df)   
        #print()
        #print()
        outfile_tr.write(str(test_df))   
        outfile_tr.write("\n\n")
 
        # Go to the next experiment
        experiment_counter += 1
     
    #print("Experiments Completed.\n")
    outfile_tr.write("Experiments Completed.\n\n")
 
    # Print the test stats   
    print("------------------------------------------------------------------")
    print(ALGORITHM_NAME + " Summary Statistics")
    print("------------------------------------------------------------------")
    print("Data Set : " + data_path)
    print()
    print("Learning Rate: " + str(LEARNING_RATE))
    print("Number of Epochs: " + str(NO_EPOCHS))
    print("Number of Hidden Layers: " + str(NO_HIDDEN_LAYERS))
    print("Number of Nodes Per Hidden Layer: " + str(
        NO_NODES_PER_HIDDEN_LAYER))
    print()
    print("Accuracy Statistics for All 5 Experiments: %s" % scores)
    print()
    print()
    print("Classification Accuracy: %.3f%%" % (
        sum(scores)/float(len(scores))))
 
    outfile_ts.write(
        "------------------------------------------------------------------\n")
    outfile_ts.write(ALGORITHM_NAME + " Summary Statistics\n")
    outfile_ts.write(
        "------------------------------------------------------------------\n")
    outfile_ts.write("Data Set : " + data_path +"\n\n")
    outfile_ts.write("Learning Rate: " + str(LEARNING_RATE) + "\n")
    outfile_ts.write("Number of Epochs: " + str(NO_EPOCHS) + "\n")
    outfile_ts.write("Number of Hidden Layers: " + str(
        NO_HIDDEN_LAYERS) + "\n")
    outfile_ts.write("Number of Nodes Per Hidden Layer: " + str(
        NO_NODES_PER_HIDDEN_LAYER) + "\n")
    outfile_ts.write(
        "Accuracy Statistics for All 5 Experiments: %s" % str(scores))
    outfile_ts.write("\n\n")
    outfile_ts.write("Classification Accuracy: %.3f%%" % (
        sum(scores)/float(len(scores))))
 
    ## Close the files
    outfile_tr.close()
    outfile_ts.close()
 

